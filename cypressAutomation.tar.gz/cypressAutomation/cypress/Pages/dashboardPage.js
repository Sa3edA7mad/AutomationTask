class DashboardPage{
    labelMsg = ".oxd-text.oxd-text--h6.oxd-topbar-header-breadcrumb-module";
    verityLogin(){
        cy.get(this.labelMsg).should('have.text','Dashboard')
    }
}
export default DashboardPage;