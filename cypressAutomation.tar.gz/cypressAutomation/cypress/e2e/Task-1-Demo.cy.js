describe ('Task 1 demo', () => {
    it('Login ', function () {
        let userName = "Admin"
        let passWord = "admin123"
        let nickname = "Nickname"
        let orderID = "123456"
        let expectedUserName = "sYwBZCIeGr Collings"

        cy.visit('https://opensource-demo.orangehrmlive.com/')
        cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').clear().type(userName)
        cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').clear().type(passWord)
        cy.get('.oxd-button').click()

        // Navigate to my Info
        cy.get(':nth-child(6) > .oxd-main-menu-item > .oxd-text').click()

        // Filling user data
        cy.get('div').find('label').contains('Nickname').parent().parent().find('input').clear().type(nickname)
        cy.get(':nth-child(3) > :nth-child(1) > :nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').clear().type(orderID)

        // cy.get(':nth-child(1) > .oxd-grid-3 > .oxd-grid-item > .oxd-input-group > :nth-child(2) > .oxd-input').should('have.text', nickname)
        cy.get(':nth-child(3) > :nth-child(1) > :nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').should('have.value', "123456")

        //How to print the value of the field for debugging -> look at the value in the assertion !!

        cy.get('div').find('label').contains('Nickname').parent().parent().find('input').then((x)=>{
            expect(x).to.have.value(nickname)
        })
        cy.get('.oxd-userdropdown-name').then( (x) => {
            expect(x.text()).to.equal(expectedUserName)
        })
    });
})
