import LoginPage from "../Pages/loginPage";
import DashboardPage from "../Pages/dashboardPage";

describe ('Task 1 demo', () => {
    let userData;
    before(()=>{
        // cy.getCookies().should('not.be.empty')
        cy.clearCookies()
        cy.getCookies().should('be.empty')

        cy.visit('https://opensource-demo.orangehrmlive.com/')

        cy.fixture( "testData").then((data)=>{
            userData = data;
        })
    })


    it('Login ', function () {
            cy.get(':nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').clear().type(userData.userName)
            cy.get(':nth-child(3) > .oxd-input-group > :nth-child(2) > .oxd-input').clear().type(userData.passWord)
            cy.get('.oxd-button').click()

            // Navigate to my Info
            cy.get(':nth-child(6) > .oxd-main-menu-item > .oxd-text').click()

            // Filling user data

             cy.get('div').find('label').contains('Nickname').parent().parent().find('input').clear().type(userData.nickname)
            // .contains("Nickname").find('input').clear().type(userData.nickname)
            cy.get(':nth-child(3) > :nth-child(1) > :nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').clear().type(userData.orderID)

            // cy.get(':nth-child(1) > .oxd-grid-3 > .oxd-grid-item > .oxd-input-group > :nth-child(2) > .oxd-input').should('have.text', nickname)
            cy.get(':nth-child(3) > :nth-child(1) > :nth-child(2) > .oxd-input-group > :nth-child(2) > .oxd-input').should('have.value', "123456")

            //How to print the value of the field for debugging -> look at the value in the assertion !!

                ccy.get('div').find('label').contains('Nickname').parent().parent().find('input').then((x)=>{
                expect(x).to.have.value(userData.nickname)
            })
            cy.get('.oxd-userdropdown-name').then( (x) => {
                expect(x.text()).to.equal(userData.expectedUserName)
                expect(x.text()).to.equal(userData.expectedUserName)
            })
    });
    it.only('POM', ()=> {
        const ln = new LoginPage();
        const db = new DashboardPage();
        ln.setUserName(userData.userName);
        ln.setPassword(userData.passWord);
        ln.clickSubmit();
        db.verityLogin();
    })
})
